<?php
    header("Location:viewChildFollowUps.php");
?>