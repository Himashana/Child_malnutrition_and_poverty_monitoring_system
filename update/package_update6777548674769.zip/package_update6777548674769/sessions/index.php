<?php
    header("Location:malnutritionMonitoring.php");
?>