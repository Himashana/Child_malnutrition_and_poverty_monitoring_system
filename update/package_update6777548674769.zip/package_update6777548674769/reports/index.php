<?php
    header("Location:newReport.php");
?>