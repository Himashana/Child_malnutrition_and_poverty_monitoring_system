<?php
    header("Location:viewChilds.php");
?>