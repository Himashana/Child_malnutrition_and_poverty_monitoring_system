<?php
    header("Location:viewInventory.php");
?>